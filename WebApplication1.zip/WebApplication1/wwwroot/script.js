﻿// Плавный скролл к разделам при нажатии на ссылки в навигации
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Вставка изображений продуктов
const menuItems = document.querySelectorAll('.menu-item');

menuItems.forEach(item => {
    const productId = item.dataset.productId;
    const img = document.createElement('img');
    img.src = `D:\\БГУИР\\2 курс\\РПИ\\Кафе\\image\\product${productId}.jpg`; // Путь к изображениям продуктов
    img.alt = `Product ${productId}`;
    item.appendChild(img);
});

// Открытие модального окна с изображением продукта при клике
menuItems.forEach(item => {
    item.addEventListener('click', function () {
        const productId = item.dataset.productId;
        const modalImg = document.querySelector('#productModal img');
        modalImg.src = `images/product${productId}.jpg`; // Путь к изображениям продуктов
        document.getElementById('productModal').style.display = 'block';
    });
});

// Закрытие модального окна при клике на кнопку "Закрыть" или на область вне модального окна
document.querySelectorAll('.close, #productModal').forEach(element => {
    element.addEventListener('click', function () {
        document.getElementById('productModal').style.display = 'none';
    });
});
